import FeatureAbout from "./_features/About";
export default function Home() {
  return (
   <section>
     <FeatureAbout />
   </section>
  );
}
