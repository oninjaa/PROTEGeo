"use client";

import ContentAbout from "./components/ContentAbout";
import Team from "./components/Team";

export default function FeatureAbout() {
  return (
    <>
      <ContentAbout />
      <Team />
    </>
  );
}
